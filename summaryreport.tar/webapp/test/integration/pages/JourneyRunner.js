sap.ui.define([
    "sap/fe/test/JourneyRunner",
	"sl/report/summaryreport/test/integration/pages/PurchaseRequestReportList.gen",
	"sl/report/summaryreport/test/integration/pages/PurchaseRequestReportObjectPage.gen"
], function (JourneyRunner, PurchaseRequestReportListGenerated, PurchaseRequestReportObjectPageGenerated) {
    'use strict';

    const runner = new JourneyRunner({
        launchUrl: sap.ui.require.toUrl('sl/report/summaryreport') + '/test/flpSandbox.html#slreportsummaryreport-tile',
        pages: {
			onThePurchaseRequestReportListGenerated: PurchaseRequestReportListGenerated,
			onThePurchaseRequestReportObjectPageGenerated: PurchaseRequestReportObjectPageGenerated
        },
        async: true
    });

    return runner;
});

